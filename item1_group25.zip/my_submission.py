'''

2017 IFN680 Assignment

Team no.: 25
Student Name and ID:
    Doyou Baek n9544411
    Wai Wing Chan n9781463
    Zhiyi Wu n9589147
Date: 25 September 2017

'''

import numpy as np
import pattern_utils
import population_search

#------------------------------------------------------------------------------

class PatternPosePopulation(population_search.Population):
    '''
    This class has the overridden methods(evaluate and mutate) and set_distance_image.
    The detail of each function is explained in each section of the function.
 
    '''
    def __init__(self, W, pat):
        '''
        Constructor. Simply pass the initial population to the parent class constructor.
        @param
          W : initial population
          pat:a target shape to be detected.
        '''
        self.pat = pat
        super().__init__(W)
    
    def evaluate(self):
        '''
        Evaluate the cost of each individual.
        Store the result in self.C
        That is, self.C[i] is the cost of the ith individual.
        The the best individual seen so far is updated to
            self.best_w 
            self.best_cost 
        @return 
           the minimun cost of each generation            
        '''
        
        #Evaluation the average pixels value of self.C[i].
        for idx, pose in enumerate(self.W):
            self.C[idx], verts = self.pat.evaluate(self.distance_image, pose)
            
        # find the minimum cost of all costs of the generation.
        # if there is np.nan, choose the minimum cost among the floats.
        try:
            i_min = np.nanargmin(self.C)
            cost_min = self.C[i_min]
        
        #Execpt when all cost is np.nan, replace it with np.inf
        except ValueError:
            cost_min = np.inf

        # Compare the minimum cost of this generation to the best cost so far. 
        # If the minimum cost is lower than the best cost, update the best cost.
        if cost_min < self.best_cost:
            self.best_w = self.W[i_min].copy()
            self.best_cost = cost_min
            
        #return the munimum cost of this generation.  
        return cost_min
 

    def mutate(self):
        '''
        Mutate each individual.
        The x and y coords should be mutated by adding with equal probability 
        -1, 0 or +1. That is, with probability 1/3 x is unchanged, with probability
        1/3 it is decremented by 1 and with the same probability it is 
        incremented by 1.
        The angle should be mutated by adding the equivalent of 1 degree in radians.
        @post:
          self.W has been mutated.
        '''
        # 1 degree
        degree = np.pi/180
        # mutates the x coord, y coord, angle and scale of object
        self.W[:,0] = self.W[:,0] + np.random.choice([-1,0,1], self.n)
        self.W[:,1] = self.W[:,1] + np.random.choice([-1,0,1], self.n)
        self.W[:,2] = self.W[:,2] + np.random.choice([-degree,0,degree], self.n)  
        self.W[:,3] = self.W[:,3]  + np.random.choice([-1,0,1], self.n)
        
         #return the mutated self.W
        return self.W
    
        
    def set_distance_image(self, distance_image):
        #set the imd image to be used for evalatuion.
        self.distance_image = distance_image 
#------------------------------------------------------------------------------        

def initial_population(region, scale = 10, pop_size=20):
    '''
    Initialise the (x,y) coords of each population in the edge based image region randomly
    @param
        rmx, rMX: x coord of each population
        rmy, rMY: y coord of each population
    @return
        W
        
    '''        
    # initial population: exploit info from region
    rmx, rMx, rmy, rMy = region
    W = np.concatenate( (
                 np.random.uniform(low=rmx,high=rMx, size=(pop_size,1)) ,
                 np.random.uniform(low=rmy,high=rMy, size=(pop_size,1)) ,
                 np.random.uniform(low=-np.pi,high=np.pi, size=(pop_size,1)) ,
                 np.ones((pop_size,1))*scale
                 #np.random.uniform(low=scale*0.9, high= scale*1.1, size=(pop_size,1))
                        ), axis=1)    
    return W

    '''
    test_particle_filter_search1 is to evaluate the best number of budget.
    test_particle_filter_search2 is to find the best balance of population and generation at the identifed budget.
    
    '''
def test_particle_filter_search1(image = True, testN_12 = 100,  generation_12 = 500,  population12 = 50 ):

    '''
     Test 1 & 2: 
        Use the 'imd' images in make_test_image_1 and make_test_image_2 to find the best computational budget.
        Test1 uses the imd with two triangles and squares as an input and test2 uses the imd2 with one triangle as an input.
        Run the individual evaluation on fixed population of 50 and generation 100. The test will be executed for 100 times.
    @param
        image(A boolean value): If the parameter is true, the 'imd' image in make_test_image_1 is processed.
                         Otherwise,the 'imd' image in make_test_image_2 is processed.
        testN_12 (integer): the number of testing times
        generation_12 (integer): the number of generations    
        population_12 (integer): A number of individuals
        
    @output
        a csv file for test1 data or test2 data.

    '''
   
    if image == True:
        # use the imd image with two triangles and two squares
        imf, imd , pat_list, pose_list = pattern_utils.make_test_image_1(True)
        ipat = 2 # index of the pattern to target
    else:
        #the imd2 with one triangle
        imf, imd , pat_list, pose_list = pattern_utils.make_test_image_2(True)
        ipat = 0 # index of the pattern to target of the pattern to target
        
    # Narrow the initial search region
    pat = pat_list[ipat] #  (100,30, np.pi/3,40),
    # Set the region and scale to initialise the population. 
    xs, ys = pose_list[ipat][:2]
    region = (xs-20, xs+20, ys-20, ys+20)
    scale = pose_list[ipat][3]
    

    column12 = 4     #4 columns in the output file: population, generation, evaluation, best solution.


    
    #test 1 & test 2 imd image with the fixed number of individuals
    test_1_2 = np.zeros((generation_12 ,testN_12, column12), dtype='object') #, dtype=float or object
    for i in range(generation_12):
        #generation is i, and it is increased.
        W = initial_population(region, scale, population12) #initialise the individual   
        pop = PatternPosePopulation(W, pat)
        pop.set_distance_image(imd)

        for j in range(testN_12):
             #execute 100 times per generation.
            Lw, Lc = pop.particle_filter_search(i+1,log=True)
            test_1_2[i][j][0] = i+1
            test_1_2[i][j][1] = population12
            test_1_2[i][j][2] = (i+1)*population12
            test_1_2[i][j][3]= pop.best_cost
    
    if image == True:
        with open('test1_final.csv', 'wb') as csvfile:
            #  np.savetxt(csvfile, header="popluation,  generation,  evaluation,  best solution")
            for slice_2d in test_1_2:
                np.savetxt(csvfile, slice_2d, fmt = ['%i', '%i', '%i', '%f'], delimiter=',')
                
    else:
        with open('test2_final.csv', 'wb') as csvfile:
            #  np.savetxt(csvfile, header="popluation,  generation,  evaluation,  best solution")
            for slice_2d in test_1_2:
                np.savetxt(csvfile, slice_2d, fmt = ['%i', '%i', '%i', '%f'], delimiter=',')
 


def test_particle_filter_search2(image = True, testN_34 = 100, budget=1400):
    '''
     Test 3 & 4: 
        Use the 'imd' images in make_test_image_1 and to make_test_image_2 to find the best computational budget.
        Test1 uses the imd with two triangles and two squares as an input and test2 uses imd2 with one triangle as an input.
        Run the evaluation on each possible combination of population and generation at a fixed budget of 1400.
        The test will be running 100 times.

    @param
        Image (A boolean value): If the parameter is true, the 'imd' image in make_test_image_1 is processed.
                                 Otherwise,the 'imd' image in make_test_image_2 is processed.
        testN_34(integer): the number of repeated tests.
        budget: the number of individual evaluations
    
    @output
        a csv file for test3 data or test4 data.
    '''
    if image == True:
        # use the imd image with two triangles and two squares
        imf, imd , pat_list, pose_list = pattern_utils.make_test_image_1(True)
        ipat = 2 # index of the pattern to target
    else:
        #the imd2 with one triangle
        imf, imd , pat_list, pose_list = pattern_utils.make_test_image_2(True)
        ipat = 0 # index of the pattern to target
        
    # Narrow the initial search region
    pat = pat_list[ipat] #  (100,30, np.pi/3,40),

    # Set the region and scale to initialise the population. 
    xs, ys = pose_list[ipat][:2]
    region = (xs-20, xs+20, ys-20, ys+20)
    scale = pose_list[ipat][3]


    imf, imd , pat_list, pose_list = pattern_utils.make_test_image_1(True)
    ipat = 2 # index of the pattern to target
    pat = pat_list[ipat] #  (100,30, np.pi/3,40),

    xs, ys = pose_list[ipat][:2]
    region = (xs-20, xs+20, ys-20, ys+20)
    scale = pose_list[ipat][3]
    
    #test 1 & test 2 imd image with  the fixed the population
    test_3_4 = np.zeros((5000,testN_34, 4), dtype='object') #4000 indicates the index of test 3 array (largest row number)

    # calculate cost of each population and generation combination nased on their scores. 
    row = 0 #This variable is used for how many rows will be generated in the output csv file
    for i in range(budget):
        #pop_size= i
        i = i + 1
        if ((int)(budget % i) == 0):
        #set to consider only the pop*gen=budget cases
            po = (int)(budget / i)
            W = initial_population(region, scale, po) 
            pop = PatternPosePopulation(W, pat)
            pop.set_distance_image(imd)
            #execute 100 times per population and generation.
            for j in range(testN_34):  
                Lw, Lc = pop.particle_filter_search(i+1,log=True)
                test_3_4[row][j][0] = i
                test_3_4[row][j][1] = po
                test_3_4[row][j][2] = i*po
                test_3_4[row][j][3]= pop.best_cost
            row = row +1

    if image == True:
        # save the data to csv file (header="generation, popluation,  generation*population combination,  test time,  cost")
        with open('test3_final.csv', 'wb') as csvfile:
            for slice_2d in test_3_4:
                np.savetxt(csvfile, slice_2d, fmt = ['%i', '%i', '%i', '%f'], delimiter=',')

    else:
        with open('test4_final.csv', 'wb') as csvfile:
          #  np.savetxt(csvfile, header="popluation,  generation,  evaluation,  best solution")
            for slice_3d in test_3_4:
                for slice_2d in slice_3d:
                    np.savetxt(csvfile, slice_2d, fmt = ['%i', '%i', '%i', '%f'], delimiter=',')
   
if __name__=='__main__':
    '''
    Choose which imd images need to be used. 
    If a boolean parameter 'True' is pased, the 'imd' image in make_test_image_1 is processed.
        Otherwise,the 'imd' image in make_test_image_2 is processed.
    '''
    '''
    test_particle_filter_search1
        The first parameter: 'True' for test1 , 'False' for test2
        The second parameter: the number of  repeated tests 
        The third parameter: the number of generation. .
        The forth parameter: A fixed number of population. 
    '''
    #different images for test1 and test2, the number of generation, the number of test.
    test_particle_filter_search1(True, 100, 500, 50)
    '''
        test_particle_filter_search2
        The first parameter: 'True' for test3 , 'False' for test4
        The second parameter: the number of  repeated tests 
        The third parameter: the number of compuational budget
    '''
    #different images for test1 and test2, the number of repeated tests, the number of budget.
    #test_particle_filter_search2(True, 100, 1400)

